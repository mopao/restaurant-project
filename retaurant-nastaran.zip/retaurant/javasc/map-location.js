
windows.onload=myMap;
function myMap() {
    var mapOptions = {
        center: new google.maps.LatLng(43.790186, -79.388952),
        zoom:5,
        };
   var map= new google.maps.Map(document.getElementById("map"), mapOptions);
}